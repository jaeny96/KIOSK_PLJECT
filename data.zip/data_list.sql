-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: data
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `list`
--

DROP TABLE IF EXISTS `list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `list` (
  `Id` varchar(20) NOT NULL,
  `Pw` varchar(20) DEFAULT NULL,
  `Name` varchar(10) DEFAULT NULL,
  `Gender` varchar(1) DEFAULT NULL,
  `IdNum` varchar(6) DEFAULT NULL,
  `PhoneNum` varchar(11) DEFAULT NULL,
  `Word` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list`
--

LOCK TABLES `list` WRITE;
/*!40000 ALTER TABLE `list` DISABLE KEYS */;
INSERT INTO `list` VALUES ('a1234','12345','abcd','여','990102','01012341234',''),('donghyun','1111','허동현','남','990203','01022223333',''),('hyunhee','1111','안현희','남','900101','01011112222',''),('jaeny','1','Oh Jisu','여','961016','01011112222','ㅎㅎ'),('jaeny96','1234','janey','여','961016','01012341234',''),('jeongeun','7777','김정은','여','990707','01077777777','웹개발자'),('jinsung','1212','안진성','남','961212','01012121212',''),('jisoo','3333','오지수','여','960303','01033333333','개발자'),('js','1','오지수','여','961016','01066419235','yeah'),('mijeong','1010','박미정','여','941010','01010101010',''),('minkyu','2222','최민규','남','940202','01022222222','프로그래머'),('minkyu22','1234','1234','남','990202','01088888888','코딩왕'),('minsoo','5555','권민수','여','950505','01055555555',''),('moono','1111','나문오','남','930101','01011111111','사업가'),('seokbong','4444','이석봉','남','890112','01077772222',''),('seongho','1111','안성호','남','981111','01011111111','웹개발자'),('seongryul','6666','김성열','남','000606','01066666666',''),('suenghwan','6666','이승환','남','910808','01088884444',''),('sunggu','5555','이선구','남','951212','01066655552',''),('taegen','2222','엄태근','남','910606','01066662222',''),('taeho','9999','김태호','남','950909','01099999999','사업가'),('taeil','8888','김태일','남','890808','01088888888','개발자'),('taeyang','3333','유태양','남','890505','01077778888',''),('wonho','4444','정원호','남','890404','01044444444','사장님'),('wonho33','1234','정원호','남','891204','01088882222','호우'),('yeonjoo','7777','정연주','여','950403','01077771111','');
/*!40000 ALTER TABLE `list` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-01 16:10:56
